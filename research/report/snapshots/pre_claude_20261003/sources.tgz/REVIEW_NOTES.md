# Review notes: "Read the Label" (MFE 230GA final project, solo research extension)

Prepared 2026-10-02 for Hashim. The project was already submitted with the team; this folder is the solo extension run as a learning exercise. Nothing here was committed or pushed to the team repo (jack-duncan/230GA-Final-Project).

## Start here

- **The report:** `report/report.pdf`, 116 pages.
  - Executive Summary: p. 1.
  - Section 1, "What Did I Try?": pp. 2-6 (brief limit 5 pages).
  - Section 2, "What Did I Learn?": pp. 7-10 (limit 4 pages).
  - References: pp. 11-12. Appendices A-E: pp. 13-116.
  - The source is `report/report.tex`.
- **Verdict: Do not implement.**
  1. The team's "climate-transition attention" series is FRED EMVENRGYENVREG, an equity-volatility news tracker, not a climate-concern measure.
  2. COVID cannot separate the timing from simply being short the Brown leg.
  3. A rule frozen before its 1994-2009 test failed (timing alpha -0.18% a year, t -0.27).
  4. Every timed rule lost over the 2022-2026 holdout.
  - The one pre-registered pass is an optimized industry-momentum book tested on 1931-1969. It fails the deflated appraisal ratio and has a holdout alpha of -0.34%, so it earns a paper-trading pilot, not capital.
- **Before you use the report anywhere,** resolve the items in the next section. None is rendered in the PDF; each sits in `report.tex` as a `%% OPEN ITEM (Hashim)` comment, or is noted below.

## Open items only you can resolve

1. **The "ChatGPT" replies are simulated.** Every reply in the four exchanges came from a separate language model instructed to answer as ChatGPT, not from a live ChatGPT session. The report says this in Section 1.5, Section 2.8 and the Appendix A provenance note. No text credits ChatGPT itself with what the stand-in did. Read strictly, the brief's ChatGPT requirement is still unmet. To meet it:
   - paste each `exchange/0N_*/prompt.md`, plus the follow-ups in 01 and 02, into ChatGPT;
   - save the replies over `chatgpt_response.md` and `chatgpt_followup_response.md`;
   - rerun the fact-checks;
   - run `uv run python report/build_transcripts.py`;
   - then re-derive Table 3, Section 2.8 and the four evaluations.

   Two frozen tests took their designs from these replies: the 1994-2009 rule (exchange 01) and the 1931-1969 run (exchange 03). Their windows are spent, so they cannot be redrawn.
2. **Your own role, Section 1.3** (`report.tex` about line 112). Add one clause on what you decided and checked yourself. About 1.5 lines fit without breaking the page limit; this was tested in a throwaway copy.
3. **Appendix D.7** (about line 603). Say who wrote the prompts and ran the fact-checks. This depends on item 2.
4. **Teammate spelling.** The `\CR` macro prints "Cristhian", the spelling in the HW1 author list. The verbatim prompts, the WhatsApp log and the module name `M2_christhian_tests` use "Christhian".
5. **"Our team of five"** appears in the verbatim exchange 01 prompt (Appendix A.1). Please confirm the team size.
6. **Group number and title-page credit line.** The group is 4 or 5, and a credit line could name the teammates. There is a comment in the title block.
7. **Title-page date.** It now reads "October 2026", because Appendix D reports work done on 2026-10-02. Change it if you prefer September.

## What changed on 2026-10-02

The work on 2026-09-26 paused while the final revision agent was mid-edit. I resumed from that partially revised `report.tex`. The pre-resume files are in `report/snapshots/` (`report_paused_1120.*` and `*_pre_w7_20261002*`). The state after the workflow is in `report/snapshots/post_w7_20261002/`.

**Triage.** Five streams sorted the reviews of the 10:58 draft into done and still needed:
- the number audit (`report/audit_numbers_r2.md`);
- the brief, voice and clarity critique (`report/critique_r2.md`);
- the red team's second round (`exchange/04_red_team/round2/revisions.md`);
- an independent re-run of the red team's numbers;
- an M7 and Appendix A consistency check.

A separate checker verified each stream's list. Result: 201 verified edits (4 high, 82 medium, 115 low). One agent applied 192 of them. Nine were duplicates or superseded and four were reserve space cuts that were not needed. The checkers rejected one more.

**Final audit.** Each round used five lenses: front-section numbers, Section 2 numbers, appendix numbers, brief compliance, and voice and LaTeX. A skeptic checked every finding before it was applied.
- Round 1 confirmed 52 findings (4 medium), and all were fixed.
- Round 2 confirmed 21, all low, and all were fixed. The loop stopped there.

**The changes that matter most:**
- **Page limit.** Section 1 had run onto p. 7 because Table 3 floated there. It now ends on p. 6. Table 3 is set smaller with a shorter caption, and about a dozen small text cuts pay for the rest. No brief item was cut.
- **ChatGPT provenance** (the fallback wording). Section 2.8 is now "Critical evaluation of the ChatGPT exchanges" and judges "the model in the ChatGPT role". Section 1.5 gives the true reason no live session was used. The Appendix A evaluations no longer name ChatGPT as the actor.
- **Second pre-registered test.** Section 2.9 had said "the one pre-registered test failed". The report has two pre-registered tests, and the 1931-1969 one passed. Fixed.
- **Verdict wording.** "The gain is a Brown-leg exposure" became "is not separable from" that exposure, which is what Section 2 shows.
- **Style exposures (brief item 3a).** Section 2.2 now reports the Green-minus-Brown spread's BOND (duration) loading and the COVID momentum and duration exposures the FF3 hedge left open. Its head no longer overclaims.
- **M7 numbers.**
  - The deflated-Sharpe caption had said the book passes with "three or fewer" trials; it now says two or fewer for both windows.
  - Section 2.7's Benjamini-Hochberg (BH) sentence was clarified: the pooled correction keeps no test.
  - A stale "re-hash once saved" note was updated.
  - The frozen run's 25 bp result is now labeled correctly.
- **Appendix D** now lists every number computed only once, as Section 1.3 promised. Before, the pointer led nowhere.
- **Figures.** The M1 standardized-measures and M7 grid-windows figures were replotted with plain labels. Every output table is byte-identical; only `M7_preregistration_hash.csv` changed, in its run-timestamp column, and its hashes still match.

**Independent re-run of the red team's numbers.** Its numbers were the only ones in the body still computed once. `exchange/04_red_team/checks/verify_fc04b_independent.py` recomputes them without the red team's check code; it shares only the team library and data loaders. It ran in about 5 seconds.
- `fc04b_results.json`: 899 of 1,071 numeric values compared, maximum absolute difference 0.
- `fc04_results.json`: 65 of 230 compared, maximum difference 1.1e-5.
- Output: `exchange/04_red_team/checks/out/independent_rerun/`.

**Housekeeping.**
- Each `exchange/*/evaluation.md`, and the Evaluation section of each `interaction.md`, now matches the evaluation text the report prints. Appendix A rebuilt byte-identical.
- `logs/lit_digest.md` gained a section on the data sources and statistical methods the report cites.

**Bibliography:** All 27 entries were checked against Crossref, the publishers' pages, SSRN or NBER, and every one exists as cited. Four were updated:
  - Lehnherr, Mehta and Nagel now cites the published version, *Financial Analysts Journal* 81(2), 51-66 (2025), instead of the 2024 SSRN paper. A second agent confirmed this correction. The key `lmn2024` is unchanged.
  - Treynor and Mazuy now has full initials (J. L., K. K.).
  - Eskildsen, Ibert, Jensen and Pedersen (2026) now carries its SSRN number, 6527562.
  - Baker, Bloom, Davis and Kost (2019) keeps the NBER working paper and notes its 2026 *Journal of Financial Economics* publication.

**Build:** tectonic, no errors, 0 overfull boxes, no undefined references or citations. The PDF renders no "Pending", "??" or draft markers, and has no em dashes.

## Caveats about how this was produced

- **Simulated ChatGPT** (open item 1). The exchange folders still say "Tool: ChatGPT" and "ChatGPT opened with..." in their own records. Read "ChatGPT" there as "the model in the ChatGPT role". Appendix A's meta lines say so.
- **Exchange 02's follow-up reply** was generated without its first reply in context: a safeguard blocked the agent that would have re-read it. Its fixes were still applied and the tests passed. Appendix A and the exchange 02 evaluation say this.
- **Exchange 03 fact-check rounds.** Exchange 03 has two fact-check rounds. Table 3 and Appendix A use the round-2 re-check, 93 claims with 11 wrong: `exchange/03_robustness_design/round2/factcheck.md`, also in `report/transcripts_src/03_factcheck.txt`. Round 1 (72 claims, 8 wrong) is kept at `exchange/03_robustness_design/factcheck.md`.
- **Zero-month counts.** During the 2026-09-26 run I told you the attention series was zero in 11 months before 2021-10 and 40 after. The correct counts are 12 of 441 and 39 of 59, and the report uses them.
- **Interruptions on 2026-09-26.** A usage limit stopped the work from 03:55 to 05:43 PDT. Three workflows (W2-W4) finished only partly, and their findings were recovered from the workflow journals. The final revision agent was then stopped at the 11:20 pause, which is why this session started with a triage.
- **Markdown write block.** The harness does not let subagents write Markdown report files. The agents returned their text and the orchestrator saved it, which is why some files carry an orchestrator save time rather than the agent's.
- **Limits the report states itself:** the 1994-2009 window is out of sample for returns but not for design. M2's commodity-hedge primary test is not strictly blind, because a smoke test printed it four minutes before the code fixing it was written; its result is null. The holdout is a single 48-month window.

## Not done (lower priority)

- The Executive Summary is about 490 words. The critique suggested trimming it to about 330 with a thesis-first opening. Page 1 has 8 pt free.
- Some appendix module tables still print code-style labels (critique 3.2.h).
- Section 2 has about 1.7 lines spare on p. 10, so any addition there must replace text. Section 1 has about 6 lines spare on p. 6.
- The `\pending` macro is still defined in `report.tex`, but nothing uses it. The transcript builder would use it only if an exchange file were missing.

## How to rebuild

```
cd research
uv run python report/make_tables.py          # generated tables in report/tables/
uv run python report/build_transcripts.py    # Appendix A
cd report && tectonic -X compile --keep-logs report.tex
cd .. && uv run --with pypdf python report/page_map.py   # page limits check
```

**Appendix A precedence.** For each file, `build_transcripts.py` prints the newer of `exchange/NN_*/<file>.md` and `report/transcripts_src/NN_<file>.txt`. The two copies are identical now. If you edit an evaluation, edit both copies, or the newer one wins silently. For exchange 04, round 1 lives in `transcripts_src/04_*.txt` and round 2 in `04b_*.txt`.

## Folder guide

- `report/`: `report.tex` and `.pdf`, `preamble.tex`, `make_tables.py`, `build_transcripts.py`, `page_map.py`, the reviews (`audit_numbers*.md`, `critique*.md`), `outline.md` and `snapshots/`.
- `modules/M1..M8/`: each module's `run.py`, `FINDINGS.md` and `VERIFY.md`. Where they differ, VERIFY's latest round wins.
  - M1: signal audit.
  - M1b: alternative signals.
  - M2: Christhian's four tests.
  - M3: alpha versus beta.
  - M4: EPA emissions.
  - M5: industry momentum and the carbon-constrained optimizer.
  - M6: shrinkage timing.
  - M7: project-wide robustness ledger.
  - M8: frozen 1994-2009 test.
- `exchange/01..04/`: the four exchanges, each with its prompt, reply, fact-check, evaluation and `interaction.md`. Exchange 03 has a `round2/` re-check, and exchange 04 has a second red-team round in `round2/`.
- `outputs/tables`, `outputs/figures`: every module output. `*_tests_ledger.csv` logs every inferential test (23,923 in total).
- `lib/`:
  - `team_pipeline.py`: a bit-for-bit port of the team notebook, covered by 14 tests in `test_team_pipeline.py`.
  - `common.py`: data loaders.
  - `save_returned_files.py`: saves files returned by workflow agents.
- `logs/`: `replication.md` (the audit of the team code), `lit_digest.md`, `style_guide.md`, `hw_context.md` and `whatsapp_halfway.md`.
- `data/`: raw downloads and derived series.
- `STATUS.md`: the full run log.
- Not copied to Downloads: `.venv` (rebuild with `uv sync`) and `scratch/` (working files, including the W7 triage and audit scripts).
