# Robustness design: Deciding the verdict under 23,923 tests

Tool: ChatGPT
Date: 2026-09-26
Purpose: robustness design

## Prompt

You are the skeptical member of an investment committee. Your job is to design the robustness and multiple-testing framework that decides my project's final verdict. Everything you need is below.

SETTING. This is my solo extension of our team's MFE 230GA (Active Asset Management, UC Berkeley) final project. The brief grades thesis 40%, execution 40% and originality 20%, and requires "Do not implement" when there is no alpha. Our team's thesis: short a Brown industry leg (Util, Ships, Aero, Steel, BldMt, from the Fama-French 49), hedged with rolling 60-month FF3 betas, for 3 or 6 months after "climate-transition attention" crosses its expanding 80th percentile. The six variants use a raw or macro-purified signal with either hold, or a continuous weight. Validation is 2010-01 to 2022-07, the holdout 2022-08 to 2026-07. The verdict is Do not implement. I ran eight modules; an independent verifier reproduced each. Each module names its primary tests in its code; only the 1994-2009 rule (item 7) has a hash and timestamps proving they came first.

EVIDENCE (annualized; Newey-West(6) t, p from t(n-k)).
1. Team record. Validation: the 6-month rules earn FF3 alphas of 2.1% to 2.5% (t 2.2 to 2.6). Holdout: all six lose 0.5% to 3.8% a year net (FF3 alpha t down to -2.19), and the IC flips from -0.09 to +0.12. Audit: the team's "2 of 32 cells survive Holm" were two 24-month COVID regressions with normal p-values (0 of 32 with t(n-4)); a missing October 2025 CPI print created the whole Pure-versus-Original holdout gap; the emissions file has no source, units or date.
2. The signal is FRED EMVENRGYENVREG, a volatility-news tracker for energy and environmental regulation. Its z-score correlates -0.0004 with the Ardia et al. Media Climate Change Concerns index (MCCC) and 0.12 with climate policy uncertainty (CPU), through overall volatility news (partial r 0.05). It is exactly zero in 31 of 48 holdout months.
3. MCCC and CPU in the identical machinery: 0 of 12 validation alphas reach t 1.96 (EMV: 4 of 6), all six MCCC holdout alphas are negative, and the smallest Holm p over 40 primary tests is 1.00. A signal-free always-short Brown position earns 71% of the COVID alpha.
4. Christhian's tests (8-and-8 legs, FF5+UMD+commodity controls, HML source, 5/10/25 bp costs): 8,091 alpha tests, 0 positive survivors under Holm or BH; 0 of 900 attention-rule holdout alphas are positive.
5. Alpha versus beta. A traded 10-year Treasury factor (BOND) plus UMD makes every holdout alpha slightly more negative; rates moved holdout returns by 0.5 pp a year at most. The Lewellen-Nagel beta-timing term is negative (-0.6% to -1.1%), and the always-short benchmark carries it too. The COVID gain is market and size exposure the lagged hedge left open.
6. Emissions. On EPA supply-chain intensities Aero and Ships rank 31st and 20th of 49 (the team file: 3rd and 2nd of 41). The EPA-ranked Green-minus-Brown spread earns 6.4% post-2010 (t 1.72) and 9.6% in the holdout (t 1.61), but its pre-specified FF5+UMD alpha is 4.7% (t 1.52). Its full-sample alpha, 4.5% (t 2.58), comes from short CMA and UMD loadings and a 2022 sort applied back to 1970.
7. Frozen rule. A pre-registered EMV-share rule, scored once on the unseen 1994-03 to 2009-12 window, fails 3 of 4 pass-bar components: alpha -0.18% (t -0.27), calendar-shuffle p 0.48.
8. Shrinkage timing (Lehnherr-Mehta-Nagel style ridge). Cross-validation picks the maximum penalty in 100% of monthly refits, so every forecast is the historical mean; attention lowers out-of-sample R2 at every fixed penalty.
9. Carbon-aware industry momentum (8 long, 8 short, t-12 to t-2, 10 bp). Net Sharpe 0.47, but the pre-registered FF5+UMD alphas are 1.74% (t 1.09) and 1.86% post-2010 (t 0.71), with UMD beta 0.99. A Grinold-Kahn optimizer book (IC fixed at 0.05, 5% ex-ante tracking; its alpha was exploratory) has full-sample alpha 2.17% (t 3.07, BH p 0.027) and IR 0.555, post-2010 alpha 3.12% (t 2.18), but holdout alpha -0.34% (t -0.15). Rank IC: 0.054 full sample, 0.030 holdout. Carbon frontier: at bound b = -1 long-leg carbon intensity falls 60% for an IR change of -0.005 (95% CI -0.110 to +0.096); only b = -2 costs significantly (-0.284, p 0.038).

TEST COUNT. The eight ledgers hold 23,923 tests: 155 primary, 8,113 robustness, 15,485 exploratory, 170 placebo or reference. About 4,200 have nominal p < 0.05, many of them factor loadings. They overlap heavily: shared holdout months, near-identical variants, one grid of 8,091 alphas.

UNSEEN DATA. FF49 returns start in 1926-07 and FF5 in 1963-07, but no module computed a strategy return before 1970.

WHAT I NEED, under these headings.
1. Families. How to control the family-wise error rate or the false discovery rate across a project this size: which families to define, which get Holm or Romano-Wolf and which get BH or BY, whether loadings and descriptive tests belong in any family, and how to treat dependence between near-duplicate variants.
2. Deflated Sharpe. How to deflate the best Sharpe ratios for the number of trials: which ratios, what counts as a trial, how to estimate the effective number of independent trials, and every input the formula needs. I have the optimizer book (679 months, annualized Sharpe 0.555, skew -0.28, raw kurtosis 5.77; post-2010: 199 months, 0.70, 0.29, 3.66) and the EPA spread (post-2010: 0.52, 0.35, 4.77).
3. Candidates. At most two that deserve the strictest scrutiny, and the exact tests that would move each to "implement": sample, benchmark, statistic, pass bar.
4. The one robustness check most likely to overturn "Do not implement", and the result that would do it.
5. What an investment committee would still object to after all of this.
6. A prioritized checklist, at most ten items: test, pass bar, what a fail means.

RULES. Work from these numbers. Cite a paper only with authors, year and the specific claim. Label any number you have not computed as a guess. Do not propose new signals. "No candidate can reach implement" is an acceptable answer if you say why. Under 1,500 words.

## Output summary

### Reply: a framework for the final verdict (1,716 words, against a limit of 1,500)

ChatGPT opened with its bottom line: "no candidate reaches "implement" on the current evidence. The attention thesis is finished (items 1–3, 7 and 8). Two strategies from outside the thesis deserve strict scrutiny. Both fail today, and only one still has an unseen sample that could change that."

It labelled its hand arithmetic, its power estimate, the ±2% margin and the 1.5% threshold as guesses, and it cited eleven papers, each with authors, year and a specific claim.

- **Families.** "Group tests by the decision they could change, not by module."
  - A one-sided confirmatory family holding "only the tests that could flip the verdict: each candidate's pre-specified alpha test", controlled by a Romano–Wolf stepdown on a stationary block bootstrap, with Holm reported alongside.
  - All 155 module "primaries" in one project-level family, because "A committee cannot check labels a module gave itself."
  - Christhian's 8,091 alphas treated as a sensitivity analysis under BH (valid for PRDS statistics, citing Benjamini and Yekutieli 2001) or BY (a cost factor of about 9.6), and reported as a distribution, with the claim that "BY and Romano-Wolf are stricter, so they will not rescue anything."
  - No family for the exploratory tests. Loadings, descriptive statistics and placebos are excluded, because "Most of the roughly 4,200 nominal hits are loadings".
  - For near-duplicate variants: a pre-specified composite, a max-t bootstrap, or Nyholt's (2004) M_eff. For best-of-many claims: White's (2000) Reality Check or Hansen's (2005) SPA.
- **Deflated Sharpe.** The PSR and DSR formulas of Bailey and López de Prado (2014) with every input (monthly SR, T, skewness, raw kurtosis, effective trials N, V[SRₙ] in monthly units, γ ≈ 0.5772, pass bar 0.95), applied to three ratios: the optimizer book's Sharpe, its appraisal ratio ("with a UMD beta of 0.99 the raw Sharpe is mostly momentum"), and the EPA spread's post-2010 Sharpe. A trial is "every return series you looked at that could have been presented as "the strategy"", sample windows included. The effective count comes from clustering (López de Prado and Lewis 2019) or M_eff; V = 1/(T−1) gives a lower bound on SR₀; Lo (2002) corrects for autocorrelation. Its hand-computed table put the book's full-sample DSR at 0.99, 0.94 and 0.81 for N = 10, 100 and 1,000, the post-2010 book at 0.90, 0.62 and 0.34, and the EPA spread at 0.71 for N = 10. It failed the EPA spread even at N = 2 and said the book's appraisal ratio (about 0.41) clears 0.95 "only if the effective number of trials is at most about 7 (guess)".
- **Candidates.**
  - A, the carbon-aware optimizer book. The holdout is "Too short either to confirm the alpha or to kill it" (alpha standard error about 2.3%). It proposed a frozen, hashed run on "1927-07 to 1969-12" against FF3 + UMD, with FF5 + UMD on 1963–1969 as a secondary test; a pass bar of alpha t ≥ 2.0, a positive alpha before and after 1948, no significant carbon cost, and a project-wide DSR on the appraisal ratio of at least 0.95; and a guessed power of about two-thirds for a true 2% alpha. It stated that "The carbon ranks use 2022 intensities" and accepted this "because carbon acts as a constraint, not as the source of return."
  - B, the EPA Green-minus-Brown spread: a post-2010 FF5 + UMD alpha test with MCCC innovations as a control, citing Pástor, Stambaugh and Taylor (2022). With no clean unseen sample, "its only route is live paper-trading."
- **The one check.** The frozen pre-1970 run, overturning the verdict only with an FF3 + UMD alpha of "roughly 1.5% a year or more (guess) with one-sided t ≥ 2.0", the same sign in both halves and DSR ≥ 0.95. "Even that would justify only "implement at pilot size with paper-trading," because the post-1970 evidence is exploratory and the holdout is flat."
- **Committee objections.** "It is just momentum" (UMD beta 0.99); momentum crash risk (Daniel and Moskowitz 2016; skew −0.28); low power, concluding that ""Do not implement" rests on insufficient evidence, not on evidence of no alpha"; unverifiable pre-registration outside item 7; data provenance; implementability ("costs above 10 bp are untested"); and a single 2022 regime in the holdout.
- **Checklist.** Ten items, each with a pass bar and a fail reading: (1) the frozen pre-1970 run; (2) DSR on the appraisal ratio with clustered trials; (3) one-sided Romano–Wolf on the 155 primaries; (4) Hansen's SPA over all strategy series; (5) a holdout TOST with a ±2% margin; (6) the EPA spread with the MCCC control, where a fail would mean "Its returns came from a shock in climate concern"; (7) an ALFRED data audit; (8) a crash stress on 1932 and 2009; (9) ETF proxies at 25 bp; (10) the carbon frontier on pre-1970 data.

## Evaluation

**ChatGPT's statistics hold up; its reading of our books does not.** The fact-check scored 93 claims: 67 correct, 15 partly correct, 11 wrong and none unverifiable. Every formula and citation checks out, all ten cells of its deflated Sharpe table reproduce to within 0.005, and its bottom line (no candidate reaches "implement") matches mine.

**The framework is what I kept.** Families are defined by the decision a test could change, so loadings, placebos and exploratory rows sit outside every family. The ratio to deflate is the appraisal ratio: the optimizer book earns 4.53% over FF5 (t = 5.21) but 2.17% once UMD enters, so its raw Sharpe flatters it. A best-of-many claim needs a max-t or SPA test over every series I could have presented. And the book's one untouched window, 1931–1969, deserved a frozen, hashed, single run.

**Eleven claims were wrong, and three trace back to my prompt.** I printed the equal-weight book's UMD beta (0.99) beside the optimizer's numbers, and two of its claims rest on it; the optimizer loads 0.27 (t = 15.2). I never named the book's carbon source, so it guessed "2022 intensities". The other eight are its own. Romano–Wolf is not stricter than BH: a lone BH rejection on the 8,091-cell grid needs p ≤ 6.2e-6, while max-t would flag the grid's best cell (p = 0.00018) at an effective count below about 285. Loadings are 32% of the nominal hits, not "most". M2 and M5 did test 25 bp. "The BOND control helps" contradicts M3. Its window cannot start before 1931-07 (the optimizer needs 60 months), and the 5% tracking target holds prewar residual volatility down (5.14% against 5.44%). "Insufficient evidence, not evidence of no alpha" is false for the attention thesis: each of the six rules rejects a +2% holdout alpha at one-sided p ≤ 0.0016. It also broke the word limit (1,716 against 1,500).

**Several of its pass bars would have misread our data.** The DSR clause in its pre-1970 bar is decided by post-1970 data and fails on its own arithmetic beyond 7 trials, so its "one check" could never overturn anything. Its ±2% TOST calls a significantly negative holdout "insufficient evidence". Its MCCC control raises the EPA spread's alpha (the shock loading is negative), and the pass is knife-edge (t = 2.13 or 1.85, by shock construction). "No significant carbon cost" rewards low power.

**It missed the conflict between its own yardsticks.** At 42 effective trials a 5% max-t bar is 3.03 and a 0.95 DSR needs about 3.85; the book's t of 3.07 sits between them, and the reply never says which governs. It ignored decay (2.99% in validation, −0.34% in the holdout) and gave no reading of a fail at roughly 0.6 power.

**What I adopted** (adopted_checks.md, hashed at 15:49 UTC before any pre-1970 return of the book existed): all 23,923 tests sorted into seven families; one-sided Holm and BH on the 73 distinct primary alphas; BH and BY on the grids, by window; Romano–Wolf and SPA over two search families; the deflated appraisal ratio, required in both windows; a holdout margin of a quarter appraisal ratio; a 25 bp cost stress; the frozen run with three pre-set readings; and a verdict map. The rule it lacked: max-t decides whether an alpha survives the search, and only the DSR can move a verdict. I dropped the 155-row family (M1's Fisher test, p = 1e-32, would "survive" it), the post hoc composite, the ±2% margin, the MCCC pass test, ETF proxies and a crash budget set after 2009.

**The frozen run passed and the verdict held.** The book earned 1.95% a year over FF3+UMD before 1970 (t = 2.45; halves 1.71% and 0.90%), but its deflated appraisal ratio is 0.559 and its holdout alpha −0.34%, so it moves to paper trading at pilot size. Do not implement stands.
